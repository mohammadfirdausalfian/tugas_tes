package com.example.recyclerkotlin_1

data class  User(val name:String, val address: String)
